# recipe-pipeline — reusable animation bundle

Everything needed to drop the **recipe-pipeline** animation into your own Quarto
RevealJS deck. Extracted from https://github.com/EmilHvitfeldt/tidy-animations

## Contents

- `js/infra.html` — shared `TM` helpers (needed by every animation)
- `js/recipe-pipeline.html` — the animation module
- `css/demos.css` — shared styles + the per-animation classes
- `recipe-pipeline.qmd` — the original example deck: copy its `{=html}` colour-config
  block and the slide block straight into your presentation

## Wiring it up

1. Copy `js/` and `css/` into your project.

2. In your deck's YAML (or `_quarto.yml`):

   ```yaml
   format:
     revealjs:
       theme: [default, css/demos.css]
       width: 1280
       height: 720
       include-in-header:
         text: |
           <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.2/anime.min.js"></script>
       include-after-body:
         - js/infra.html
         - js/recipe-pipeline.html
   ```

3. Paste the colour-config `{=html}` block and the slide block from
   `recipe-pipeline.qmd` wherever you want the slide.

Keep `width: 1280, height: 720` — the module lays elements out in absolute
coordinates against a fixed-size stage. Fragment ids must stay unique within
your deck.
